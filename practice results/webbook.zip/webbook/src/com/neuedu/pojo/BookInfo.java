package com.neuedu.pojo;

public class BookInfo {
	private String image;
	private String bookname;
	private String isbn;
	private Integer pagenum;
	private String author;
	private String publisher;
	private Double original;
	private Double current;
	private String summary;
	public BookInfo(String image, String bookname, String isbn, Integer pagenum, String author, String publisher,
			Double original, Double current, String summary) {
		super();
		this.image = image;
		this.bookname = bookname;
		this.isbn = isbn;
		this.pagenum = pagenum;
		this.author = author;
		this.publisher = publisher;
		this.original = original;
		this.current = current;
		this.summary = summary;
	}
	public BookInfo() {
		super();
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public Integer getPagenum() {
		return pagenum;
	}
	public void setPagenum(Integer pagenum) {
		this.pagenum = pagenum;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public Double getOriginal() {
		return original;
	}
	public void setOriginal(Double original) {
		this.original = original;
	}
	public Double getCurrent() {
		return current;
	}
	public void setCurrent(Double current) {
		this.current = current;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	
}
