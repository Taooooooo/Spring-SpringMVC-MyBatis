package com.neuedu.pojo;

public class ShoppingCart {
	private String bookname;
	private String isbn;
	private Double unitprice;
	private Integer num;
	private Double totalprice;
	private Double total;
	private Integer state;
	public ShoppingCart(String bookname, String isbn, Double unitprice, Integer num, Double totalprice, Double total,
			Integer state) {
		super();
		this.bookname = bookname;
		this.isbn = isbn;
		this.unitprice = unitprice;
		this.num = num;
		this.totalprice = totalprice;
		this.total = total;
		this.state = state;
	}
	public ShoppingCart() {
		super();
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public Double getUnitprice() {
		return unitprice;
	}
	public void setUnitprice(Double unitprice) {
		this.unitprice = unitprice;
	}
	public Integer getNum() {
		return num;
	}
	public void setNum(Integer num) {
		this.num = num;
	}
	public Double getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(Double totalprice) {
		this.totalprice = totalprice;
	}
	public Double getTotal() {
		return total;
	}
	public void setTotal(Double total) {
		this.total = total;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	
}
