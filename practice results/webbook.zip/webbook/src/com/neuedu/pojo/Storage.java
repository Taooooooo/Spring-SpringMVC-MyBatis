package com.neuedu.pojo;

public class Storage {
	private String bookname;
	private String isbn;
	private Double unitprice;
	private Integer state;
	public Storage(String bookname, String isbn, Double unitprice, Integer state) {
		super();
		this.bookname = bookname;
		this.isbn = isbn;
		this.unitprice = unitprice;
		this.state = state;
	}
	public Storage() {
		super();
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public Double getUnitprice() {
		return unitprice;
	}
	public void setUnitprice(Double unitprice) {
		this.unitprice = unitprice;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
		    
}
