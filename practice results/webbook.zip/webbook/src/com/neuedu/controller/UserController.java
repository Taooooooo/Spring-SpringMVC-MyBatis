package com.neuedu.controller;


import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.neuedu.pojo.User;
import com.neuedu.service.UserService;

@Controller
@RequestMapping(value="/user")
public class UserController {
	
	
	@Autowired
	private UserService userService;
	
	//1.public int insertUser(User user);
	//2.public List<User> findUserList();
	/**
	 * 
	 * 2��������û�����أ�
	 */
	@RequestMapping(value="/addUser")
	public ModelAndView addUser(User user){
		userService.insertUser(user);
		ModelAndView mv =new ModelAndView();
		mv.setViewName("show");
		return mv;
	}
	
	//3.public Integer login(@Param("email") String email,@Param("password") String password);	
	@RequestMapping(value="/login")
	public ModelAndView login(User user,String email,String password){
		email=user.getEmail();
		password=user.getPassword();
		int count=userService.login(email,password);
		ModelAndView mv =new ModelAndView();
		if(count>0){
			mv.setViewName("welcome");
		}
		else{
			mv.setViewName("failed");
		}
		return mv;
	}
	
	
}