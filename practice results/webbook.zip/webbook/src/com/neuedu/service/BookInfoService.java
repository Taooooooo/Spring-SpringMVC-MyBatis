package com.neuedu.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.neuedu.pojo.BookInfo;

public interface BookInfoService {
	public List<BookInfo> findBookInfoList();
	public List<BookInfo> findBookInfoByIsbn(@Param("isbn")String isbn);
}
