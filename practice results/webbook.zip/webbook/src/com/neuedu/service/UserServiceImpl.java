package com.neuedu.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;

import com.neuedu.mapper.UserMapper;
import com.neuedu.pojo.User;

public class UserServiceImpl implements UserService {
	@Autowired
	private UserMapper userMapper;
	@Override
	public int insertUser(User user){
		return userMapper.insertUser(user);
	}
	@Override
	public List<User> findUserList(){
		return userMapper.findUserList();
	}
	@Override
	public Integer login(String email,String password){
		return userMapper.login(email,password);
	}
}
