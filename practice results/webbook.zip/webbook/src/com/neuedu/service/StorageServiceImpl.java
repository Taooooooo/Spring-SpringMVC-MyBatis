package com.neuedu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.neuedu.mapper.StorageMapper;
import com.neuedu.pojo.Storage;

public class StorageServiceImpl implements StorageService {
	@Autowired
	private StorageMapper storageMapper;
	@Override
	public int countMax(){
		return storageMapper.countMax();
	}
	@Override
	public List<Storage> findStoragePage(int begin, int PageSize){
		return storageMapper.findStoragePage(begin, PageSize);
	}
	@Override
	public int deleteStorage(String isbn){
		return storageMapper.deleteStorage(isbn);
	}
	@Override
	public int insertStorage(String isbn){
		return storageMapper.insertStorage(isbn);
	}
}
