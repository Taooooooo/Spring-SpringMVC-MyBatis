package com.neuedu.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.neuedu.pojo.ShoppingCart;

public interface ShoppingCartService {
	
	//1.����ͼ���¼�����ﳵ������isbn��
	public int insertShoppingCart(String isbn);
	//2.
	public List<ShoppingCart> findShoppingCartList();
	//3.
	public int deleteShoppingCart(String isbn);
	//4.
	public int countMax();
	//5.
	public List<ShoppingCart> findShoppingCartPage(@Param("begin") int begin,@Param("pageSize") int PageSize);

}
