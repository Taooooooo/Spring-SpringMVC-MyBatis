package com.neuedu.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.neuedu.pojo.Storage;

public interface StorageService {
	public int deleteStorage(String isbn);
	public int insertStorage(String isbn);
	public int countMax();
	public List<Storage> findStoragePage(@Param("begin") int begin,@Param("pageSize") int PageSize);
}
