package com.neuedu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.neuedu.mapper.ShoppingCartMapper;
import com.neuedu.pojo.ShoppingCart;

public class ShoppingCartServiceImpl implements ShoppingCartService {
	@Autowired
	private ShoppingCartMapper shoppingCartMapper;
	@Override
	public int insertShoppingCart(String isbn){
		return shoppingCartMapper.insertShoppingCart(isbn);
	}
	@Override
	public List<ShoppingCart> findShoppingCartList(){
		return shoppingCartMapper.findShoppingCartList();
	}
	@Override
	public int deleteShoppingCart(String isbn){
		return shoppingCartMapper.deleteShoppingCart(isbn);
	}
	@Override
	public int countMax(){
		return shoppingCartMapper.countMax();
	}
	@Override
	public List<ShoppingCart> findShoppingCartPage(int begin, int PageSize){
		return shoppingCartMapper.findShoppingCartPage(begin, PageSize);
	}
}
