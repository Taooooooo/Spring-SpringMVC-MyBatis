package com.neuedu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.neuedu.mapper.BookInfoMapper;
import com.neuedu.pojo.BookInfo;


public class BookInfoServiceImpl implements BookInfoService {
	@Autowired
	private BookInfoMapper bookInfoMapper;
	@Override
	public List<BookInfo> findBookInfoList(){
		return bookInfoMapper.findBookInfoList();
	}
	@Override
	public List<BookInfo> findBookInfoByIsbn(String isbn){
		return bookInfoMapper.findBookInfoByIsbn(isbn);
	}
}
