package com.neuedu.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.neuedu.pojo.User;

public interface UserService {
	public int insertUser(User user);
	public List<User> findUserList();
	public Integer login(@Param("email") String email,@Param("password") String password);
}
